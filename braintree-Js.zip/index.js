import dotenv from 'dotenv';
import express from 'express';
import mongoose from "mongoose";
import braintree from 'braintree';
//+++++++++++++++++++++++++++++++++++++++++
import db from "./db/index.js";
//+++++++++++++++++++++++++++++++++++++++++
dotenv.config();
const app = express();
app.use(express.json());
//+++++++++++++++++++++++++++++++++++++++++
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log("Database Connection Successful!");
    } catch (err) {
        console.error("Database Connection Failed!", err);
        process.exit(1);
    }
};
connectDB();
//+++++++++++++++++++++++++++++++++++++++++
//Config
//+++++++++++++++++++++++++++++++++++++++++
var gateway = new braintree.BraintreeGateway({
    environment: braintree.Environment.Sandbox,
    merchantId: process.env.BRAINTREE_MERCHANT_ID,
    publicKey: process.env.BRAINTREE_PUBLIC_KEY,
    privateKey: process.env.BRAINTREE_PRIVATE_KEY,
});
//+++++++++++++++++++++++++++++++++++++++++
// app.get('single-transtion', (req, res) => {
//     gateway.transaction.sale({
//             amount: "5.00",
//             paymentMethodNonce: "nonce-from-the-client",
//             options: {
//                 submitForSettlement: true,
//             },
//         },
//         function(err, result) {
//             if (err) {
//                 console.error(err);
//                 return;
//             }
//             if (result.success) {
//                 console.log("Transaction ID: " + result.transaction.id);
//             } else {
//                 console.error(result.message);
//             }
//         }
//     );
// })
app.get('/generate-payment-token', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    try {
        const result = await gateway.paymentMethod.create({
            customerId: req.body.customerId,
            paymentMethodNonce: req.body.paymentMethodNonce,
            options: { makeDefault: true }
        });
        if (result.success) {
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = result.paymentMethod.token;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Success";
            return res.status(200).json(resData);
        } else {
            console.error(result.message);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = result.message;
            return res.status(200).json(resData);
        }
    } catch (error) {
        console.error(error);
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r = null;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = false;
        resData.message = "Error generating client token";
        return res.status(200).json(resData);
    }
});
//+++++++++++++++++++++++++++++++++++++++++
app.get('/generate-token', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    try {
        const response = await gateway.clientToken.generate({});
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r = response.clientToken;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Success";
        return res.status(200).json(resData);
    } catch (error) {
        console.error(error);
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r = null;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = false;
        resData.message = "Error generating client token";
        return res.status(200).json(resData);
    }
});
//+++++++++++++++++++++++++++++++++++++++++
app.post('/create-customer', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.customer.create({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        phone: req.body.phone,
        company: req.body.company,
        fax: req.body.fax,
        website: req.body.website
    }, async (err, result) => {
        if (result.success) {
            //+++++++++++++++++++++++++++++++++++++++++
            const paymentResult = await gateway.paymentMethod.create({
                customerId: result.customer.id,
                paymentMethodNonce: req.body.paymentNonce,
                options: { makeDefault: true }
            });
            //+++++++++++++++++++++++++++++++++++++++++
            req.body.customerID = result.customer.id;
            req.body.paymentToken = paymentResult;
            //+++++++++++++++++++++++++++++++++++++++++
            const createOBJ = await new db.userModel(req.body).save();
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r.mongoResult = createOBJ;
            resData.r.braintreeResult = result;
            resData.r.braintreePaymentResult = paymentResult;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Created";
            return res.status(200).json(resData);
        } else {
            console.error(err);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Filed";
            return res.status(200).json(resData);
        }
    });
});
//+++++++++++++++++++++++++++++++++++++++++
app.post('/update-customer', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.customer.update(req.body.customerID, {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
    }, async (err, result) => {
        if (result.success) {
            //+++++++++++++++++++++++++++++++++++++++++
            const filter = { customerID: req.body.customerID };
            //+++++++++++++++++++++++++++++++++++++++++
            const updateOBJ = await db.userModel.findOneAndUpdate(filter, {
                firstName: req.body.firstName,
                lastName: req.body.lastName
            });
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r.mongoResult = updateOBJ;
            resData.r.braintreeResult = result;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Updated";
            return res.status(200).json(resData);
        } else {
            console.error(err);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Filed";
            return res.status(200).json(resData);
        }
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.get('/find-customer', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.customer.find(req.query.customerID, async function(err, customer) {
        if (!err) {
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r.braintreeResult = customer;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Find Customer Details";
            return res.status(200).json(resData);
        } else {
            console.error(err);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Filed";
            return res.status(200).json(resData);
        }
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.get('/delete-customer', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.customer.delete(req.query.customerID, (err) => {
        if (!err) {
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r.braintreeResult = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = true;
            resData.message = "Sucess";
            return res.status(200).json(resData);
        } else {
            console.error(err);
            //+++++++++++++++++++++++++++++++++++++++++
            resData.r = null;
            //+++++++++++++++++++++++++++++++++++++++++
            resData.status = false;
            resData.message = "Filed";
            return res.status(200).json(resData);
        }
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.post('/create-plan', async (req, res) => {
    //+++++++++++++++++++++++++++++++++++++++++
    // 1: Monthly billing (bills every month)
    // 3: Quarterly billing (bills every 3 months)
    // 6: Semi-annual billing (bills every 6 months)
    // 12: Annual billing (bills once a year)
    // 24: Biennial billing (bills every 2 years)
    //+++++++++++++++++++++++++++++++++++++++++
    // The trial timeframe specified in a plan. It is required if the trial period is set to true and must be 1-3 digits. If you specify a trial duration of 0, the gateway will start the subscription immediately and not consider it to include a trial period.
    //+++++++++++++++++++++++++++++++++++++++++
    // The trial unit specified in a plan. Specify day or month
    //+++++++++++++++++++++++++++++++++++++++++
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.plan.create({
        name: req.body.name,
        description: req.body.description,

        trialPeriod: req.body.trialPeriod,
        trialDuration: req.body.trialDuration,
        trialDurationUnit: req.body.trialDurationUnit,
        
        billingFrequency: req.body.billingFrequency,
        currencyIsoCode: (req.body.currencyIsoCode) ? req.body.currencyIsoCode : "USD",
        price: req.body.price
    }).then(result => {
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r.braintreeResult = result;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Sucess Plan Created";
        return res.status(200).json(resData);
    }).catch(error => {
        console.log(error);
    });

})
//+++++++++++++++++++++++++++++++++++++++++
app.get('/list-plan', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.plan.all().then(result => {
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r.braintreeResult = result;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Plan List";
        return res.status(200).json(resData);
    }).catch(error => {
        console.log(error);
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.get('/find-plan', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.plan.find(req.query.planID).then(result => {
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r.braintreeResult = result;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Plan Single";
        return res.status(200).json(resData);
    }).catch(error => {
        console.log(error);
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.post('/update-plan', async (req, res) => {
    //+++++++++++++++++++++++++++++++++++++++++
    // 1: Monthly billing (bills every month)
    // 3: Quarterly billing (bills every 3 months)
    // 6: Semi-annual billing (bills every 6 months)
    // 12: Annual billing (bills once a year)
    // 24: Biennial billing (bills every 2 years)
    //+++++++++++++++++++++++++++++++++++++++++
    // The trial timeframe specified in a plan. It is required if the trial period is set to true and must be 1-3 digits. If you specify a trial duration of 0, the gateway will start the subscription immediately and not consider it to include a trial period.
    //+++++++++++++++++++++++++++++++++++++++++
    // The trial unit specified in a plan. Specify day or month
    //+++++++++++++++++++++++++++++++++++++++++
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    gateway.plan.update(req.body.planID, {
        name: req.body.name,
        description: req.body.description,
        billingFrequency: req.body.billingFrequency,
        currencyIsoCode: (req.body.currencyIsoCode) ? req.body.currencyIsoCode : "USD",
        price: req.body.price
    }).then(result => {
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r.braintreeResult = result;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Sucess Plan Updated";
        return res.status(200).json(resData);
    }).catch(error => {
        console.log(error);
    });
})
//+++++++++++++++++++++++++++++++++++++++++
app.post('/create-subscription', async (req, res) => {
    let resData = {
        status: false,
        r: {},
        message: "",
    };
    //+++++++++++++++++++++++++++++++++++++++++
    const { paymentMethodToken } = req.body;
    //+++++++++++++++++++++++++++++++++++++++++
    const result = await gateway.subscription.create({ paymentMethodToken, planId: req.body.planId });
    //+++++++++++++++++++++++++++++++++++++++++
    if (result.success) {
        //+++++++++++++++++++++++++++++++++++++++++
        resData.r.braintreeResult = result.subscription.id;
        //+++++++++++++++++++++++++++++++++++++++++
        resData.status = true;
        resData.message = "Sucess";
        return res.status(200).json(resData);
    } else {
        console.log(result);
        resData.status = true;
        resData.message = "Failed";
        return res.status(200).json(resData);
    }
})
//+++++++++++++++++++++++++++++++++++++++++
app.get('/cancel-subscription', async (req, res) => {
    const result = await gateway.subscription.cancel(req.body.subscriptionID);
})
//+++++++++++++++++++++++++++++++++++++++++
const port = 3000;
//+++++++++++++++++++++++++++++++++++++++++
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})